package URI::sftp;

use strict;
use warnings;

use parent 'URI::ssh';

our $VERSION = '1.72';
$VERSION = eval $VERSION;

1;
